-- set abilities
if (firstFrame == nil) then
    local count, players = GetAllPlayers()
    if (count == 0) then return end
    firstFrame = false
    for i = 1, count do
        local player = players[i]
        player.SetAbility(1, "Tesla", false)
        player.SetAbility(2, "Engine", false)
    end
    _, plat13 = RaycastRoundedRect(-30, 0, 0, 1)
    _, plat24 = RaycastRoundedRect(30, 0, 0, 1)
    plat13 = plat13.GetBoplBody()
    plat24 = plat24.GetBoplBody()
end

if (plat24force ~= nil) then 
    plat24force = plat24force - GetDeltaTime()
    print("plat24force: "..plat24force)
    if (plat24force < 0) then
        mass = plat24.GetMass()
        plat24.SetMass(1)
        plat24.AddForce(0, 200000)
        plat24.SetMass(mass)
        plat24force = nil
    end
end

if (plat13force ~= nil) then 
    plat13force = plat13force - GetDeltaTime()
    print("plat13force: "..plat13force)
    if (plat13force < 0) then
        mass = plat13.GetMass()
        plat13.SetMass(1)
        plat13.AddForce(0, 200000)
        plat13.SetMass(mass)
        plat13force = nil
    end
end

-- detect change in bodies
local c, bodies = GetAllBoplBodys()
if (c == oldCount) then return end
oldCount = c

for i = 1, c do
    local body = bodies[i]
    local type = body.GetObjectType()
    if (type == "Telsa") then type = "Tesla" end
    if (type == "Tesla" or type == "RocketEngine") then
        CustomAbility(body, type)
        body.Destroy()
    end
end

function CustomAbility(abilityObject, type)
    local abilities = {
        ["Tesla"] = Dodge,
        ["RocketEngine"] = ShootFrom
    }

    local x, y = abilityObject.GetPos()
    local player = GetClosestPlayer(x, y)
    
    -- find player index
    local count, players = GetAllPlayers()
    local pIndex
    for i = 1, count do
        if (player == players[i]) then
            pIndex = i
            break
        end
    end
    
    if pIndex and abilities[type] then
        print(tostring(abilities[type]))
        abilities[type](pIndex)
    end
end

function ShootFrom(pIndex)
    if (pIndex == 2 or pIndex == 4) then
        SpawnGrenade(24.5, 0, 1, -60, 25, 3)
    else
        SpawnGrenade(-24.5, 0, 1, 60, 25, -3)
    end
end

function Dodge(pIndex)
    if (pIndex == 2 or pIndex == 4) then
        plat24force = 0.1
    else
        plat13force = 0.1
    end
end
