if (not NotFirstFrame) then
    AbilityCooldownLastFrame = {}
    print("first frame")
end
NotFirstFrame = true
_, players = GetAllPlayers()
i = 1
while (players[i] != nil) do
    player = players[i]
    for j = 1,3,1 do 
        AbilityMaxCooldown = player.GetAbilityMaxCooldown(j)
        AbilityCooldownRemaining = player.GetAbilityCooldownRemaining(j)
        --if theres a ability in that slot and the game changed its cooldown sence the last frame.
        if (AbilityCooldownRemaining != 1000000 and AbilityCooldownLastFrame[i*3 + j] ~= nil and AbilityCooldownLastFrame[i*3 + j] ~= AbilityCooldownRemaining) then
            NewMaxAbilityCooldown = AbilityMaxCooldown/3
            --calculate the ability cooldown to remove to make it take NewMaxAbilityCooldown seconds to charge
            --the game already removed GetDeltaTime() cooldown so take that into acount.
            --amount to subtract every second if the game didnt also change the cooldown
            DecrementRate = AbilityMaxCooldown / NewMaxAbilityCooldown;
            CooldownToRemove =  DecrementRate * GetDeltaTime() - GetDeltaTime()
            --print(AbilityCooldownRemaining)
            --print(AbilityCooldownLastFrame[i])
            player.SetAbilityCooldownRemaining(j, AbilityCooldownRemaining - CooldownToRemove)
        end
        AbilityCooldownLastFrame[i*3 + j] = player.GetAbilityCooldownRemaining(j)
    end
    i = i + 1
end