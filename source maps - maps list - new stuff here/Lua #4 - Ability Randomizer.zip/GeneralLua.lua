function RandomizeAbilities(player, plat)
    local abilities = {
        "Roll", "Dash", "Grenade", "Bow", "Engine", "Blink", "Gust", "Grow", "Rock", "Missile", 
        "Spike", "TimeStop", "SmokeGrenade", "Platform", "Revive", "Shrink", "BlackHole", 
        "Invisibility", "Meteor", "Macho", "Push", "Tesla", "Mine", "Teleport", "Drill", 
        "Grapple", "Beam", "Duplicator"
    }
    
    for i = 1, 3 do
        local ability = abilities[math.floor(math.random(29))]
        player.SetAbility(i, ability, true)
        player.SetAbilityCooldownRemaining(i, 0)
    end

    if (plat == nil) then return end
    bod = plat.GetBoplBody()
    if (bod == nil) then return end
    bod.SetScale(bod.GetScale() - 0.01)
    if (bod.GetScale() <= 0.31 and not bod.IsBeingDestroyed()) then
        bod.Destroy()
        if (player.GetPlatform() == plat1) then plat1 = nil
        else plat2 = nil end
    end
end

if firstFrame == nil then
    plat1 = SpawnPlatform(-45, 10, 2.5, 2.5, 1, 0, 0.6275, 0, 1, 1)
    plat2 = SpawnPlatform(45, 10, 2.5, 2.5, 1, 0, 0.6275, 0, 1, 1)
    plat1.SetBaseScale(0.05)
    plat2.SetBaseScale(0.05)
    p1Scale = 2.5
    p2Scale = 2.5
    firstFrame = false
end

if (IsTimeStopped()) then return end

if (plat1 ~= nil) then
    if (plat1.GetScale() > p1Scale) then
        plat1.SetScale(p1Scale)
    else
        p1Scale = plat1.GetScale()
    end
end

if (plat2 ~= nil) then
    if (plat2.GetScale() > p2Scale) then
        plat2.SetScale(p2Scale)
    else
        p2Scale = plat2.GetScale()
    end
end

_, players = GetAllPlayers()
for _, player in ipairs(players) do
    if ((player.GetPlatform() == plat1 and plat1 ~= nil) or (player.GetPlatform() == plat2 and plat2 ~= nil)) then
        RandomizeAbilities(player, player.GetPlatform())
    end
end
