_, left = RaycastRoundedRect(-55, 10, 90, 1)
_, lefty = RaycastRoundedRect(-88, 30, 90, 1)
_, right = RaycastRoundedRect(55, 10, 90, 1)
_, righty = RaycastRoundedRect(88, 30, 90, 1)
_, middletop = RaycastRoundedRect(0, 6, 0, 1)
_, middlebottom = RaycastRoundedRect(0, -13, 0, 1)
_, c1 = RaycastRoundedRect(-22, 15, 0, 1)
_, c2 = RaycastRoundedRect(-7, 15, 0, 1)
_, c3 = RaycastRoundedRect(8, 15, 0, 1)
_, cno = RaycastRoundedRect(22, 15, 0, 1)
count, players = GetAllPlayers()
i = 1
while (i <= count) do
    player = players[i]
    player.SetSpeed(100)
    i = i + 1
end

left.SetHomeRot(left.GetHomeRot() - 5)
right.SetHomeRot(right.GetHomeRot() + 5)

lefty.DropAllPlayers(75)
righty.DropAllPlayers(75)
middletop.DropAllPlayers(75)
middlebottom.DropAllPlayers(75)
c1.DropAllPlayers(75)
c2.DropAllPlayers(75)
c3.DropAllPlayers(75)
cno.DropAllPlayers(75)

hole = SpawnBlackHole(0, 10, -5) -- Spawns a white hole at (0, 10)