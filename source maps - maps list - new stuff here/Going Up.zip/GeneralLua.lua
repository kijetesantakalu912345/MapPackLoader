if (firstFrame == nil) then
	fc = 1000
	pfc = 1000
	downamount = 0
	firstFrame = false
end

pcount, platforms = GetAllPlatforms()

pfc = fc
fc = fc + 1
downamount = downamount + (0.05 * fc/1000) 

for i = 1, pcount do
	if (not platforms[i].IsBoulder()) then
		oldhomeX, oldhomeY = platforms[i].GetHome()
		platforms[i].SetHome(oldhomeX, oldhomeY - (0.05 * fc/1000))
	end
end

print(downamount)

if (downamount > 270) then
	pcount, players = GetAllPlayers()
	for i = 1, pcount do
		px, py = players[i].GetPosition()
		SpawnExplosion(px,py,0.05)
	end
end