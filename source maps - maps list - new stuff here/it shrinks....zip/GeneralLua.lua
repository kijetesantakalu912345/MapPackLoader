count, platforms = GetAllPlatforms()
playerCount, players = GetAllPlayers()
i = count
while (i > 0) do
    platform = platforms[i]
    if (platform != nil) then
        platformBody = platform.GetBoplBody()
        if (platformBody != nil) then
            j = playerCount
            while (j > 0) do
                player = players[j]
                if (player != nil) then
                    if (player.GetPlatform() == platform) then
                        size = platformBody.GetScale()
                        platformBody.SetScale(size * 0.999)
                
                    end
                end
                j = j - 1
            end
        end
    end
    i = i - 1
end