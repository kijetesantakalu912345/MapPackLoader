if (init == nil) then
    _, circle1 = RaycastRoundedRect(0, 0, 0, 1)
    _, circle2 = RaycastRoundedRect(10, 0, 0, 1)
    init = true
end

speed = 1
circle1.SetHomeRot(circle1.GetHomeRot() - speed)
circle2.SetHomeRot(circle2.GetHomeRot() + speed)