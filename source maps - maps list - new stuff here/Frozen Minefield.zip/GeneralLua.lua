if (ff == nil) then
    i = 0
    while (i < 20) do
        SpawnMine(math.random(-98, 98), math.random(-10, 39), 1, 0, 0, 0, false)
        i = i + 1
    end
    ff = false
end