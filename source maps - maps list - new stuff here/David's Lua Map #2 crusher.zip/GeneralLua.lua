if (not NotFirstTick) then
    Platform = SpawnPlatform(0, 45, 3, 120, 1, 0, 1, 0, 0, 1)
    NewHomeY = 45
    AdditsonPerSecond = -2
end
NotFirstTick = true
if (Platform ~= nil and Platform.GetBoplBody() ~= nil and not Platform.GetBoplBody().IsBeingDestroyed()) then
    --if time isnt stoped and the platform isnt blinked move it down/up
    if (not IsTimeStopped() and not Platform.GetBoplBody().IsDisappeared()) then
        NewHomeY = NewHomeY + (AdditsonPerSecond * GetDeltaTime())
        --if its at the top or bottom flip the drectson and double its speed
        _, PosY = Platform.GetBoplBody().GetPos()
        if (((PosY < -11.3 and AdditsonPerSecond < 0) or (PosY > 45 and AdditsonPerSecond > 0))) then
            AdditsonPerSecond = -AdditsonPerSecond * 2
        end
    end
    Platform.SetHome(0, NewHomeY)
    Platform.SetScale(1)
end