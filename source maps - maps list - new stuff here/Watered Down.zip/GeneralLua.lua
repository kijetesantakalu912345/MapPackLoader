function ease(freq) return math.sin(freq * t) end
function getPlatAt(x,y)
    _, platform = RaycastRoundedRect(x, y, 0, 1)
    return platform
end

if firstFrame == nil then
    _, platforms = GetAllPlatforms()
    s1, s2 = platforms[0], platforms[1]

    t = 0.1
    speed = 0.1
    firstFrame = false

    rots = {}
    pos = {}
    for _, p in pairs(platforms) do
        if p ~= nil and p.IsBoulder() == false then -- Fixed variable reference
            rots[p] = p.GetHomeRot() -- Store the rotation for the platform
            local x, y = p.GetHome()
            pos[p] = y
        end
    end

    fallin01 = getPlatAt(-347.96, 145.50)
end

function disableFallingAbilties()
    c, bodies = GetAllBoplBodys()
    i = 1
    while (i <= c) do
        body = bodies[i]
        if (body.GetObjectType() == "AbilityPickup") then
            body.Destroy()
        end
        i = i + 1
    end
end


function tick()
    for index, plat in pairs(platforms) do
        if plat ~= nil and plat.IsBoulder() == false then
            local x, y = plat.GetHome()
            y = pos[plat]
            local speedMult = 1
    
            if index % 2 == 0 then
                speedMult = 2
            end
    
            plat.SetHome(x + speed, (y + ease(0.3) * (speed)*speedMult))
            plat.SetHomeRot(rots[plat] + ease(0.3) * (3/speedMult))
        end
    end

    disableFallingAbilties()
end

tick()
t = t + 0.1 -- Increment t after updating all platforms
