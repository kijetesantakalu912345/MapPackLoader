if (firstFrame == nil) then
    _, middle = RaycastRoundedRect(0, -15, 0, 1)
    _, left = RaycastRoundedRect(-62, 8, 0, 1)
    _, right = RaycastRoundedRect(62, 6, 0, 1)
    _, top = RaycastRoundedRect(0, 30, 0, 1)

    count, players = GetAllPlayers()
i = 1
while (i <= count) do
    runners = players[i]
    runners.SetAbility(1, "Dash", false)
    runners.SetAbility(2, "Teleport", false)
    runners.SetAbility(3, "Grapple", false)
    i = i + 1
    firstFrame = false
end

randX = (math.random() - 0.5)
randY = (math.random() - 0.5)

tagger = GetClosestPlayer(randX, randY + 5)

tagger.SetAbility(1, "Meteor", false)
tagger.SetAbility(2, "Teleport", false)
tagger.SetAbility(3, "Rock", false)
end

c, bodies = GetAllBoplBodys()
if c ~= oldC then
    for _, b in ipairs(bodies) do
        if b.GetObjectType() == "AbilityPickup" then b.Destroy() end
    end
    oldC = c
end

if (init == nil) then
    _, circle1 = RaycastRoundedRect(0, 8, 0, 1)
    init = true
end

speed = 5
circle1.SetHomeRot(circle1.GetHomeRot() + speed)

left.DropAllPlayers(100)
right.DropAllPlayers(100)
middle.DropAllPlayers(100)
top.DropAllPlayers(75)



