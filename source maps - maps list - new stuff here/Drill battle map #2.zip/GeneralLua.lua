if (ff == nil) then
    count, players = GetAllPlayers()
    i = 1
    while (i <= count) do
        player = players[i]
        player.SetAbility(1, "Drill", false)
        player.SetAbility(2, "Drill", false)
        player.SetAbility(3, "Drill", false)
        i = i + 1
    end
    ff = false
end
-- disable ability orbs
c, bodies = GetAllBoplBodys()
if c ~= oldC then
    for _, b in ipairs(bodies) do
        if b.GetObjectType() == "AbilityPickup" then b.Destroy() end
    end
    oldC = c
end
count, players = GetAllPlayers()
i = 1
while (i <= count) do
    player = players[i]
    player.SetAbilityCooldownRemaining(1, 0)
    player.SetAbilityCooldownRemaining(2, 0)
    player.SetAbilityCooldownRemaining(3, 0)
    i = i + 1
end