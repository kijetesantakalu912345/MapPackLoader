-- Set offsets for parts relative to the body
armOffX = 2.7
armOffY = 1
headOff = 4
footOffX = 1.9
footOffY = 3.5
hairOffX = 1.2
hairOffY = 5
groundOff = 5.2

-- Create the Bill class
Bill = {}
Bill.__index = Bill

-- Setting the default values and getting the platforms
function Bill:new(x, y)
    local instance = setmetatable({}, Bill)
    instance.x = x
    instance.y = y
    _, instance.body = RaycastRoundedRect(x, y, 0, 1)
    _, instance.armL = RaycastRoundedRect(x - armOffX, y + armOffY, 0, 1)
    _, instance.armR = RaycastRoundedRect(x + armOffX, y + armOffY, 0, 1)
    _, instance.head = RaycastRoundedRect(x, y + headOff, 0, 1)
    _, instance.footL = RaycastRoundedRect(x - footOffX, y - footOffY, 0, 1)
    _, instance.footR = RaycastRoundedRect(x + footOffX, y - footOffY, 0, 1)

    _, instance.hair1 = RaycastRoundedRect(x - hairOffX, y + hairOffY, 0, 1)
    _, instance.hair2 = RaycastRoundedRect(x + hairOffX, y + hairOffY, 0, 1)

    instance.bodyBody = instance.body.GetBoplBody()
    instance.armLBody = instance.armL.GetBoplBody()
    instance.armRBody = instance.armR.GetBoplBody()
    instance.headBody = instance.head.GetBoplBody()
    instance.footLBody = instance.footL.GetBoplBody()
    instance.footRBody = instance.footR.GetBoplBody()
    instance.hair1Body = instance.hair1.GetBoplBody()
    instance.hair2Body = instance.hair2.GetBoplBody()
    instance.hair1Rot = instance.hair1Body.GetRot()
    instance.hair2Rot = instance.hair2Body.GetRot()
    _, instance.ground = instance:GetGround(1)
    instance.movingX = true
    instance.falling = false
    instance.velY = 0
    instance.changeX = -0.1
    instance.alive = true
    return instance
end

-- Check if there is something beneath the Bill within the specified distance
function Bill:GetGround(distance)
    resultDist, groundCheck = RaycastRoundedRect(self.x, self.y - groundOff, 270, distance)
    if (groundCheck != nil and groundCheck != self.body and groundCheck != self.armL and groundCheck != self.armR and groundCheck != self.head and groundCheck != self.footL and groundCheck != self.footR and groundCheck != self.hair1 and groundCheck != self.hair2) then
        return resultDist, groundCheck
    end
    return nil, nil
end

-- Moving Bill
function Bill:Move()
    -- If dead, then do nothing
    if (not self.alive or IsTimeStopped()) then return end

    -- Helps prevent errors and to confirm the body is there
    if (self.ground == nil) then
        gone = true
    else
        groundBody = self.ground.GetBoplBody()
        if (groundBody.IsDisappeared()) then gone = true end
    end
    
    if (gone) then
        self.falling = true
    end
    dist, ground = self:GetGround(1)
    lastDist = dist
    if (ground != nil and dist != nil) then
        self.ground = ground
        self.falling = false
        self.y = self.y - dist
        while (dist <= 0.0001) do
            self.y = self.y + 0.01
            dist, ground = self:GetGround(1)
        end
        local lastDist, ground = self:GetGround(1)
    else
        self.falling = true
        self.ground = nil
    end
    if (lastDist == nil) then local lastDist = dist end


    if (not self.falling and self.movingX) then
        self.x = self.x + self.changeX
        dist, ground = self:GetGround(0.1)
        if (ground == nil) then
            self.changeX = self.changeX * -1
            self.x = self.x + self.changeX
        end
    end

    --[[
    if (not self.falling and self.movingX) then
        self.x = self.x + self.changeX
        dist, ground = self:GetGround(1)
        if (dist == nil or lastDist == nil) then self.falling = true
        else
            if (lastDist - dist > 0.1 or lastDist - dist < 0.1) then
                self.changeX = self.changeX * -1
                self.x = self.x + self.changeX
            end
        end
    end
    ]]

    if (self.falling) then 
        self.velY = self.velY - 0.01
        self.ground = nil 
        self.y = self.y + self.velY
        if (self.velY > 0.2) then self.velY = 0.2 end
    else
        self.velY = 0
    end

    if (self.body == nil) then 
        self.movingX = false
    else
        self.body.SetHome(self.x, self.y)
        self.bodyBody.SetPos(self.x, self.y)
    end
    if (self.head == nil) then 
        self.movingX = false
    else
        self.head.SetHome(self.x, self.y + headOff)
        self.headBody.SetPos(self.x, self.y + headOff)
    end
    if (self.armL != nil) then
        self.armL.SetHome(self.x - armOffX, self.y + armOffY)
        self.armLBody.SetPos(self.x - armOffX, self.y + armOffY)
    end
    if (self.armR != nil) then
        self.armR.SetHome(self.x + armOffX, self.y + armOffY)
        self.armRBody.SetPos(self.x + armOffX, self.y + armOffY)
    end
    if (self.footL != nil) then
        self.footL.SetHome(self.x - footOffX, self.y - footOffY)
        self.footLBody.SetPos(self.x - footOffX, self.y - footOffY)
    end
    if (self.armL != nil) then
        self.footR.SetHome(self.x + footOffX, self.y - footOffY)
        self.footRBody.SetPos(self.x + footOffX, self.y - footOffY)
    end
    if (self.hair1 != nil) then 
        self.hair1Body.SetPos(self.x - hairOffX, self.y + hairOffY) 
        self.hair1Body.SetRot(self.hair1Rot)
    end
    if (self.hair2 != nil) then 
        self.hair2Body.SetPos(self.x + hairOffX, self.y + hairOffY) 
        self.hair2Body.SetRot(self.hair2Rot)
    end


    if (players != nil) then
        i = 1
        while (i < 4) do
            player = players[i]
            if (player != nil) then
                touching = player.GetPlatform()
                if (touching != nil) then
                    if (touching == self.body or touching == self.armL or touching == self.armR or touching == self.head or touching == self.footL or touching == self.footR or touching == self.hair1 or touching == self.hair2) then
                        print("Killing")
                        self.headBody.Destroy()
                        SpawnBoulder(self.x, self.y + headOff, 0.2, 0, 20, 10, "ice", 0, 0, 0, 0)
                        SpawnExplosion(self.x, self.y + headOff/2, 1)
                        self.alive = false
                    end
                end    
            end
            i = i + 1
        end
    end 
end

if (firstFrame == nil) then
    bill1 = Bill:new(-50, 21)
    bill2 = Bill:new(50, 21)
    bill3 = Bill:new(-50, -3)
    bill4 = Bill:new(50, -3)
    firstFrame = false
end

if (firstPlayerFrame == nil) then
    _, players = GetAllPlayers()
    firstPlayerFrame = false
end
bill1:Move()
bill2:Move()
bill3:Move()
bill4:Move()