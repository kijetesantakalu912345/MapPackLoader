_, plats = GetAllPlatforms()


plats[1].ShakePlatform(2, 0.5)
plats[2].ShakePlatform(2, 0.5)
plats[3].ShakePlatform(2, 0.5)
plats[4].ShakePlatform(2, 0.5)
plats[5].ShakePlatform(2, 0.5)
plats[6].ShakePlatform(2, 0.5)
plats[7].ShakePlatform(2, 0.5)
plats[8].ShakePlatform(2, 0.5)
plats[9].ShakePlatform(2, 0.5)
plats[10].ShakePlatform(2, 0.5)
plats[11].ShakePlatform(2, 0.5)

