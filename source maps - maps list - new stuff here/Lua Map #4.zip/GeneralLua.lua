if (ff == nil) then
    ff = false
    len, players = GetAllPlayers()
    --results in a value of 1 if theres only 1 player
    --resultes in 1 or 2 if there are 2 players ect ect.
    MainPlayerIndex = math.floor(math.random(1, len+1))
    MainPlayer = players[MainPlayerIndex]
    ability1 = MainPlayer.GetAbility(1)
    ability2 = MainPlayer.GetAbility(2)
    ability3 = MainPlayer.GetAbility(3)
    for index = 1,len, 1
    do
        --if its not the main player
        if (index ~= MainPlayerIndex) then
            Player = players[index]
            Player.SetAbility(1, ability1, false)
            --im lazy so im not gonna handle if they only have 1 or 2 abilitys.
            --hence the ff = false being at the start.
            --sure it will error if theres only 1 or 2 abilitys but basicly nobody does that.
            Player.SetAbility(2, ability2, false)
            Player.SetAbility(3, ability3, false)
        end
    end
end
