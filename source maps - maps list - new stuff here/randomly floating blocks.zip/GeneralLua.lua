if firstFrame == nil then
    _, platforms = GetAllPlatforms()
    platformMovementDirections = {}

    firstFrame = false
    platformMovementCooldown = 5
    CooldownTimer = platformMovementCooldown

    MovePhaseTimer = 0
    MovePhaseLengthSeconds = 3

    isInMovePhase = false

    degToRad = math.pi/180
    radius_movementPerTick = 5
end

-- radians because all of the trig functions assume radians and I'd prefer to not have a bunch of conversions everywhere
function getRandAngleRad()
    rngNum = math.random(0, 360) * degToRad
    return rngNum
end


function randomizePlatformDirections(highestPlatIndex)
    platformMovementDirections = {}
    print("length before adding stuff: " .. #platformMovementDirections)
    for i = 1, highestPlatIndex do
        table.insert(platformMovementDirections, getRandAngleRad())
    end
    
end

CooldownTimer = CooldownTimer + GetDeltaTime()


if (CooldownTimer >= platformMovementCooldown) or isInMovePhase then
    if not isInMovePhase then
        MovePhaseTimer = 0
        amountOfPlatforms = #platforms
        randomizePlatformDirections(amountOfPlatforms)
        print("directions should have rerandomized")
    end

    isInMovePhase = true

    loopNum = 1
    
    for idx, platform in pairs(platforms) do
        local boplBody = platform.GetBoplBody()
        if boplBody ~= nil then
            if platform ~= nil then
            
                x, y = platform.GetHome()
                valToAddToX = radius_movementPerTick * math.cos(platformMovementDirections[loopNum]) * GetDeltaTime()
                valToAddToY = radius_movementPerTick * math.sin(platformMovementDirections[loopNum]) * GetDeltaTime()

                platform.SetHome(x + valToAddToX, y + valToAddToY)

                loopNum = loopNum + 1
            end
        end
    end

    MovePhaseTimer = MovePhaseTimer + GetDeltaTime()
end


if MovePhaseTimer >= MovePhaseLengthSeconds then
    isInMovePhase = false
    CooldownTimer = 0
    MovePhaseTimer = 0
end