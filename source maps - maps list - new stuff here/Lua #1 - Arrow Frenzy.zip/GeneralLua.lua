if (firstFrame == nil) then
    _, platforms = GetAllPlatforms()
    circle = platforms[1]
    firstFrame = false
    elapsed = 0
    arrX = -80
end

circle.SetHomeRot(circle.GetHomeRot())

function GetVelocityFor(x, y)
    return -x/0.2, 4-y/0.2
end

interval = 0.2
elapsed = elapsed + 0.01
if (elapsed >= interval) then
    arrX = arrX + 2
    elapsed = 0
    xVel, yVel = GetVelocityFor(arrX, 40)
    SpawnArrow(arrX, 40, 1, xVel, yVel, 1, 0, 0, 1)
end

if (arrX >= 40) then
    interval = 1000
end