if (ff == nil) then
    playerCount, players = GetAllPlayers()
    if (players[1] == nil) then return end
    present = SpawnPlatform(0, 7, 10, 16, 1, 0, 0, 256, 256, 1)
    presentOpening = false
    presentOpened = false
    openingTime = 0
    ff = false
end

if (not presentOpening and not presentOpened) then
    i = playerCount
    while (i > 0) do
        player = players[i]
        if (player != nil) then
            ground = player.GetPlatform()
            if (ground != nil) then
                if (ground == present) then
                    ground.DropAllPlayers(10)
                    presentOpening = true
                    return
                end
            end
        end
    i = i - 1
    end
end

if (presentOpening) then
    w, h, r = present.GetPlatformSize()
    if (w <= 0 or h <= 0) then
        presentOpening = false
        presentOpened = true
        present.GetBoplBody().Destroy()
        SpawnGrenade(5, 7, 10, 30, 35, 0)
        SpawnGrenade(-5, 7, 10, -30, 35, 0)
        return 
    end
    present.ResizePlatform(w - 0.05, h - 0.05, r)
    SpawnArrow(0, 25, 1, math.random(0, 11) - 5, 100, math.floor(math.random(0, 257)), math.floor(math.random(0, 257)), math.floor(math.random(0, 257)), 1)
end

