if (firstFrame == nil) then
    count, players = GetAllPlayers()
    if (count == 0) then return end
interval = 0.5
c = 0
    firstFrame = false
end

c = c + GetDeltaTime()
if (c >= interval) then
    SpawnArrow(0, 20, 1, math.random(-125, 125), math.random(-60, 60), 255, 255, 255, 1)
    c = 0
end
