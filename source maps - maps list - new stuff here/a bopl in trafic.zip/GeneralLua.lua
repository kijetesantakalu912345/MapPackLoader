-- Initialization for the right-side arrows
if (firstFrame == nil) then
    _, platforms = GetAllPlatforms()
    circle = platforms[1]
    firstFrame = false
    sideElapsed = 0
interval = 0.05
sideY2=0
sideY1=0
end
-- Update elapsed time for the side arrows moving up and down
sideElapsed = sideElapsed + 0.0005
if (sideElapsed >= interval) then
    sideElapsed = 0

    -- Move sideY1 up and down between 60 and -25
    sideY1 = sideY1 + 2
    if (sideY1 <= 0) then
        sideDirection1 = 1  -- Change direction to move up
    elseif (sideY1 >= 60) then
        sideDirection1 = -1  -- Change direction to move down
    end

    -- Move sideY2 up and down between 60 and -25
    sideY2 = sideY2 + 2 
    if (sideY2 <= 0) then
        sideDirection2 = 1  -- Change direction to move up
    elseif (sideY2 >= 60) then
        sideDirection2 = -1  -- Change direction to move down
    end

    -- Spawn arrows at x = 100 and x = -100 moving toward the center with speed 45
    SpawnBoulder(100, sideY1, 0.01, -4, 0, 900,"slime", 0.4, 0.4, 0.4, 1)  -- red color for side arrows moving left
    SpawnBoulder(-100, sideY2, 0.01, 4, 0, -900,"slime", 0.4, 0.4, 0.4, 1)  -- red color for side arrows moving right
end
