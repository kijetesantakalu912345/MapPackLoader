if (firstFrame == nil) then
	framecount = 0
	pfcount = 0
	dir = 0
	firstFrame = false
	_, block = RaycastRoundedRect(-30,5,90,1)
	_, bplat = RaycastRoundedRect(0,-7.41,90,1)
	bplatbb = bplat.GetBoplBody()
end

pfcount = framecount
framecount = framecount + 1

if (not bplat.IsBoulder()) then
	oldHomeX,oldHomeY = bplat.GetHome()
	bplatbb.SetPos(oldHomeX,oldHomeY)
	bplatbb.setRot(0)
end

if (math.floor(framecount/160) > math.floor(pfcount/160)) then
	if (dir == 0) then 
		dir = 1
		if (not block.IsBoulder()) then
			block.SetHome(-30, 30)
		end
		return
	end
	if (dir == 1) then 
		dir = 2
		if (not block.IsBoulder()) then
			block.SetHome(30, 30)
		end
		return
	end
	if (dir == 2) then 
		dir = 3
		if (not block.IsBoulder()) then
			block.SetHome(30, 5)
		end
		return
	end
	if (dir == 3) then 
		dir = 0
		if (not block.IsBoulder()) then
			block.SetHome(-30, 5)
		end
		return
	end
end