if (FirstFrame == nil) then
    _, piston1 = RaycastRoundedRect(-45, 7, 0, 1)
    _, piston2 = RaycastRoundedRect(45, 7, 0, 1)
    _, handle1 = RaycastRoundedRect(-100, 7, 0, 1)
    _, handle2 = RaycastRoundedRect(100, 7, 0, 1)
    FirstFrame = false 
    return
end

speed = 0.03
p1X, p1Y = piston1.GetHome()
h1X, h1Y = handle1.GetHome()
p2X, p2Y = piston2.GetHome()
h2X, h2Y = handle2.GetHome()
piston1.SetHome(p1X + speed, p1Y)
handle1.SetHome(h1X + speed, h1Y)
piston2.SetHome(p2X - speed, p2Y)
handle2.SetHome(h2X - speed, h2Y)