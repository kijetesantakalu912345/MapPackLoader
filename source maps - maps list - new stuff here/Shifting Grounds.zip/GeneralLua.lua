if (firstFrame == nil) then
    _, platforms = GetAllPlatforms()
    s1, s2 = platforms[0], platforms[1]

    t = 0.1
    startX = -10
    endX = 10
    speed = 0.3
    up = true
    firstFrame = false
end

function ease(s)
    return math.sin(t) * s
end

for indx, plat in pairs(platforms) do
    local movingBody = plat.GetBoplBody()
    if movingBody ~= nil then
        if movingBody.GetPos ~= nil and movingBody.SetPos ~= nil then
            local x, y = movingBody.GetPos()
            if indx >= 1 and indx <= 14 then  -- Top row platforms
                movingBody.SetPos(x + ease(speed), y)
            elseif (indx >= 15 and indx <= 31) or (indx >= 33 and indx <= 47) then  -- Bottom & sudden death row platforms
                movingBody.SetPos(x - ease(speed), y)
            end            
        end
    end
end


t = t + 0.05
