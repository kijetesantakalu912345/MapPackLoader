if firstFrame == nil then
    _, platforms = GetAllPlatforms()
    s1, s2 = platforms[0], platforms[1]

    t = 0.1
    speed = 0.1
    up = true
    firstFrame = false
    slowdownrate = 50
end

for indx, plat in pairs(platforms) do
    local movingBody = plat.GetBoplBody()
    if movingBody ~= nil then
        if plat ~= nil then
            x, y = plat.GetHome()
            plat.SetHomeRot(0)
            plat.SetScale(0.5)

            if indx >= 12 and indx <= 24 then -- Top row platforms
                if x > -96.89 and y <= 5 then
                    plat.SetHome(x - speed, y) -- Move left
                elseif x <= -95.89 and y <= 5 then -- Adjusted to include equal
                    plat.SetHome(x, y + speed) -- Move up
                elseif x < 96.89 and y >= 5 then
                    plat.SetHome(x + speed, y) -- Move right
                elseif x >= 96.89 and y > 0 then
                    plat.SetHome(x, y - speed) -- Move down
                end
            end
            
            if indx >= 1 and indx <= 11 then -- Bottom row platforms
                if x < 99.89 and y >= -5 then
                    plat.SetHome(x + speed, y) -- Move right
                elseif x >= 99.89 and y > -5 then
                    plat.SetHome(x, y - speed) -- Move down
                elseif x > -96.89 and y <= -5 then
                    plat.SetHome(x - speed, y) -- Move left
                elseif x <= -95.89 and y <= 0 then -- Adjusted to include equal
                    plat.SetHome(x, y + speed) -- Move up
                end
            end
            

        end
    
    end
end

t = t + 0.05
