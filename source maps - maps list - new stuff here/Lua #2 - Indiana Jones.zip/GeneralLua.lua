if (init == nil) then
    init = true
    boulder = SpawnBoulder(-100, 60, 4, 5, -3, -10, "grass", 0, 0, 0, 0)
    interval = 10
    time = 0
end

time = time + GetDeltaTime()
if (time >= interval) then
    boulder = SpawnBoulder(-100, 60, 4, 5, -3, -10, "grass", 0, 0, 0, 0)
    interval = 10
    time = 0
end