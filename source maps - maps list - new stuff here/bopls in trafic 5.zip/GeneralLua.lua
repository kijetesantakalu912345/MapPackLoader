if (ff == nil) then
    _, p = GetAllPlayers()

    -- Adjust player properties
    p[1].SetGravityAccel(0)
    p[1].SetAirAccel(0)
    p[1].SetMaxSpeed(2)
    p[1].SetGravityMaxFallSpeed(1)
    p[1].SetAbility(1, "Dash", false)
    p[1].SetAbility(2, "Dash", false)
    p[1].SetAbility(3, "Dash", false)

    -- Initialize variables
    boost=0
    x1 = 30
    x2 = -30
    xc1 = 1
    xc2 = 0
    sc1 = 1
    sc2 = 2
    t1 = 0
    t2 = 0
    ff = true
end
--cooldown editing
if (not NotFirstFrame) then
    AbilityCooldownLastFrame = {}
    print("first frame")
end
NotFirstFrame = true
_, players = GetAllPlayers()
i = 1
while (players[i] != nil) do
    player = players[i]
    for j = 1,3,1 do 
        AbilityMaxCooldown = player.GetAbilityMaxCooldown(j)
        AbilityCooldownRemaining = player.GetAbilityCooldownRemaining(j)
        --if theres a ability in that slot and the game changed its cooldown sence the last frame.
        if (AbilityCooldownRemaining != 1000000 and AbilityCooldownLastFrame[i*3 + j] ~= nil and AbilityCooldownLastFrame[i*3 + j] ~= AbilityCooldownRemaining) then
            NewMaxAbilityCooldown = AbilityMaxCooldown/3
            --calculate the ability cooldown to remove to make it take NewMaxAbilityCooldown seconds to charge
            --the game already removed GetDeltaTime() cooldown so take that into acount.
            --amount to subtract every second if the game didnt also change the cooldown
            DecrementRate = AbilityMaxCooldown / NewMaxAbilityCooldown;
            CooldownToRemove =  DecrementRate * GetDeltaTime() - GetDeltaTime()
            --print(AbilityCooldownRemaining)
            --print(AbilityCooldownLastFrame[i])
            player.SetAbilityCooldownRemaining(j, AbilityCooldownRemaining - CooldownToRemove)
        end
        AbilityCooldownLastFrame[i*3 + j] = player.GetAbilityCooldownRemaining(j)
    end
    i = i + 1
end

-- Increment time variables
t1 = t1 + 0.05
t2 = t2 + 0.01

-- Check if t1 has reached the threshold sc1
if (t1 >= sc1) then
    -- Handle movement for x2
    if (x2 >= 80) then
        xc2 = 0
    elseif (x2 <= -80) then
        xc2 = 1
    end
    if (xc2 == 1) then
        x2 = x2 + 2
    elseif (xc2 == 0) then
        x2 = x2 - 2
    end

    -- Handle movement for x1
    if (x1 >= 80) then
        xc1 = 0
    elseif (x1 <= -80) then
        xc1 = 1
    end
    if (xc1 == 1) then
        x1 = x1 + 2
    elseif (xc1 == 0) then
        x1 = x1 - 2
    end

    -- Spawn boulders at various positions
    SpawnBoulder(x1, 50, 0.1, 0, -10-boost, 300, "slime", math.random(0, 1), math.random(0, 1), math.random(0, 1), 1)
    SpawnBoulder(x2, 50, 0.1, 0, -10-boost, 300, "slime", math.random(0, 1), math.random(0, 1), math.random(0, 1), 1)
    SpawnBoulder(-x1 + 10, 60, 0.1, 0, -10-boost, 300, "slime", math.random(0, 1), math.random(0, 1), math.random(0, 1), 1)
    SpawnBoulder(-x2 - 10, 60, 0.1, 0, -10-boost, 300, "slime", math.random(0, 1), math.random(0, 1), math.random(0, 1), 1)

    SpawnBoulder(x1 + 20, -25, 0.1, 0, 30+boost, 300, "slime", math.random(0, 1), math.random(0, 1), math.random(0, 1), 1)
    SpawnBoulder(x2 - 20, -25, 0.1, 0, 30+boost, 300, "slime", math.random(0, 1), math.random(0, 1), math.random(0, 1), 1)
    SpawnBoulder(-x1 + 30, -25, 0.1, 0, 30+boost, 300, "slime", math.random(0, 1), math.random(0, 1), math.random(0, 1), 1)
    SpawnBoulder(-x2 - 30, -25, 0.1, 0, 30+boost, 300, "slime", math.random(0, 1), math.random(0, 1), math.random(0, 1), 1)

    -- Reset t1 to 0 for the next cycle
    t1 = 0
end
--endgamefix
if (GetTimeSinceLevelLoad() >= 80) then
  boost=boost+0.02
end