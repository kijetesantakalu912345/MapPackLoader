if (firstFrame == nil) then
    count, players = GetAllPlayers()
    if (count == 0) then return end
interval = 0.8
c = 0
    firstFrame = false
end

c = c + GetDeltaTime()
if (c >= interval) then
    SpawnBoulder(math.random(-100, 100), math.random(80, 200), math.random(0.5, 2), 0, -1, 3, "space", 135, 45, 30, 1)
    c = 0
end