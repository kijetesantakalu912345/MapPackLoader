if (init == nil) then
    init = true
end

speed = 8

_, plats = GetAllPlatforms()
i = 1
if (plats ~= nil) then
    while(plats[i] ~= nil) do
        plat = plats[i]
        if (plat ~= nil and plat.IsBoulder() == false) then
            body = plat.GetBoplBody()
            if (body ~= nil) then
                x, _ = body.GetPos()
                _, y = plat.GetHome()
                newX = x - speed
                if (newX < -135) then
                    newX = 130
                    body.SetPos(newX, y)
                else 
                    plat.SetHome(newX, y)
                end
            end
        end
        i = i + 1
    end
end

_, players = GetAllPlayers()
j = 1
if (players ~= nil) then
    while(players[j] ~= nil) do
        player = players[j]
        if (player ~= nil) then
            xP, yP = player.GetPosition()
            if (xP < -120) then
                print("KILL")
                SpawnExplosion(xP, yP, 1)
            end
        end
        j = j + 1
    end
end
