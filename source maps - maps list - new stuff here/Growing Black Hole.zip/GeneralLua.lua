if (ff == nil) then
    hole = SpawnBlackHole(0, 8, 1)
    ff = false
end
hole.Grow(0.1)