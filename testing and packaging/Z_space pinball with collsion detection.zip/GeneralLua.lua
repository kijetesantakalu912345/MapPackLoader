function getRandomSign()
    if math.random(0, 1) > 0.5 then
        return 1
    else
        return -1
    end
end

function createBall()
    currBall = SpawnBoulder(94.11, 4.99, 0.25, Xvel, Yvel * getRandomSign(), AngleVel * getRandomSign(), "robot", 1, 1, 1, 1)
    setBallVars(currBall)
    return currBall
end

function setBallVars(ball)
    bb = ball.GetBoplBody()
    -- this has to be low because it happens every tick!
    bb.SetAirFriction(1.01)
    bb.SetBouncyness(1)
    -- default mass for a boulder at 0.25 scale is 9.00000002724119
    bb.SetMass(0.5)
end

if firstFrame == nil then
    firstFrame = false

    shouldSpawnBoulder = false

    Timer = 0
    TimerCooldown = 1.5

    count, players = GetAllPlayers()
    for i = 1, count do
        player = players[i]
        abilityAmount = player.GetAbilityCount()

        AmountOfInvalidAbilities = 0
        for j = 1, player.GetAbilityCount() do
            player.SetAbility(j, "Gust", false)
        end
    end

    _, allPlatforms = GetAllPlatforms()
    -- hack that erwer suggested to me with raycast rounded rect
    -- also yeah due to annoying lua syntax stuff we can't just do RaycastRoundedRect(...)[2]. we are required to do it the clunky annoying way.
    _, goal1 = RaycastRoundedRect(-88.54, 24.87, 90, 100000)
    _, goal2 = RaycastRoundedRect(85.98, 25.26, 90, 100000)
    _, goal3 = RaycastRoundedRect(-87.38, -8.41, 270, 100000)
    _, goal4 = RaycastRoundedRect(93.29, -17.58, 270, 100000)
    goals = {goal1 , goal2, goal3, goal4}
    
    goalWasScoredLastTick = false


    AngleVel = 0
    Yvel = 0
    Xvel = -175

    currentBall = createBall()
end


Timer = Timer + GetDeltaTime()

i = 1
while i < #goals+1 do
    amountOfCollisions, currCollisions = GetAllPlatformsCollisionsThatTouched(currentBall)

    j = 1
    while j < amountOfCollisions+1 do

        if currCollisions[j].GetNewPlatform() == goals[i] then
            print("GOAL SCORED ON GOAL #: " .. tostring(i))
            -- in case a player manages to die on the tick they also get a goal, because collision detection functions are always 1 tick behind
            _, allPlayers = GetAllPlayers()
            print(#allPlayers .. " | " .. i)
            if #allPlayers >= i then
                target = allPlayers[i]
                targetsPosX, targetsPosY = target.GetPosition()
                SpawnExplosion(targetsPosX, targetsPosY, 0.5)
            else
                goalX, goalY = goals[i].GetBoplBody().GetPos()
                SpawnExplosion(goalX, goalY, 1)
            end
        end
        j = j + 1
    end

    i = i + 1
end


if ((Timer >= TimerCooldown) and (goalWasScoredLastTick)) or (currentBall == nil) then
    shouldSpawnBoulder = true
    Timer = 0
end

if shouldSpawnBoulder then

    currentBall = createBall()
    shouldSpawnBoulder = false
end


if (not currentBall.GetBoplBody().IsBeingDestroyed()) and currentBall.GetBoplBody().HasBeenInitialized() then
    setBallVars(currentBall)
end